const P = window.PORTFOLIO;
const $ = (s, p=document) => p.querySelector(s);
const $$ = (s, p=document) => [...p.querySelectorAll(s)];
const sleep = ms => new Promise(r=>setTimeout(r,ms));

function toast(msg){
  const t=$("#toast"); t.textContent=msg; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),2800);
}

async function boot(){
  const lines=["YEAR: 2035","TIME: 07:42:18","SYSTEM INITIALIZATION...","Loading neural interface...","Loading memory core...","Restoring identity database...","IDENTITY SCAN..."];
  const wrap=$("#boot-lines"), bar=$("#boot-progress");
  for(let i=0;i<lines.length;i++){
    const d=document.createElement("div"); d.textContent=lines[i]; d.style.animationDelay=`${i*.08}s`; wrap.appendChild(d);
    await sleep(180);
    bar.style.width=`${Math.round((i+1)/lines.length*100)}%`;
  }
  $("#boot-status").textContent="IDENTITY RECOVERED";
  await sleep(650);
  $("#boot").classList.add("hidden"); $("#recovery").classList.remove("hidden");
  typeText($("#ai-intro"),"Donishree... can you hear me?\n\nYour memory archive has been damaged.\nI've recovered fragments of your past.\nWould you like me to reconstruct them?",24);
}

function typeText(el,text,delay=30){
  el.textContent="";
  let i=0; const tick=()=>{if(i<text.length){el.textContent+=text[i++];setTimeout(tick,delay)}};
  tick();
}

function enterApp(){
  $("#recovery").classList.add("hidden"); $("#app-shell").classList.remove("hidden");
  buildAll();
  requestAnimationFrame(()=>$("#memory-01").scrollIntoView({behavior:"smooth"}));
}
$("#begin-btn").addEventListener("click",enterApp);
$("#manual-btn").addEventListener("click",enterApp);
$("#restart").addEventListener("click",()=>location.reload());
$("#brand-reset").addEventListener("click",()=>$("#memory-01").scrollIntoView({behavior:"smooth"}));

function buildNav(){
  const nav=$("#memory-nav");
  const memories=[
    ["01","THE BEGINNING","memory-01"],["02","EDUCATION ARCHIVE","memory-02"],["03","SKILL DNA","memory-03"],
    ["04","PROJECT ARCHIVE","memory-04"],["05","MISSION LOGS","memory-05"],["06","ACHIEVEMENT VAULT","memory-06"],
    ["07","THE TIMELINE","memory-07"],["08","THE FUTURE","memory-08"],["09","FINAL RECONSTRUCTION","finale"]
  ];
  nav.innerHTML=memories.map(x=>`<button data-target="${x[2]}"><b>${x[0]}</b>${x[1]}</button>`).join("");
  $$("button[data-target]",nav).forEach(b=>b.onclick=()=>{ $("#drawer").classList.remove("open"); $("#drawer").setAttribute("aria-hidden","true"); $("#"+b.dataset.target).scrollIntoView({behavior:"smooth"}); });
  $$(".scroll-cue").forEach(b=>b.onclick=()=>$("#"+b.dataset.target).scrollIntoView({behavior:"smooth"}));
}
$("#menu-btn").onclick=()=>{$("#drawer").classList.add("open");$("#drawer").setAttribute("aria-hidden","false")};
$("#close-menu").onclick=()=>{$("#drawer").classList.remove("open");$("#drawer").setAttribute("aria-hidden","true")};

function buildSkills(){
  const box=$("#skill-network");
  const positions=[[50,42],[18,23],[80,20],[22,68],[80,67],[49,15],[51,78],[29,45],[68,45],[50,82]];
  box.innerHTML="";
  P.skills.forEach((s,i)=>{
    const n=document.createElement("button"); n.className="skill-node"; n.style.left=`${positions[i][0]}%`; n.style.top=`${positions[i][1]}%`; n.style.transform="translate(-50%,-50%)";
    n.innerHTML=`<b>${s.name}</b>`; n.onclick=()=>{ $$(".skill-node").forEach(x=>x.classList.remove("active")); n.classList.add("active"); $("#skill-inspector").innerHTML=`<span>${s.group}</span><b>${s.name}</b><p>${s.detail}</p>`; };
    box.appendChild(n);
  });
  for(let i=1;i<P.skills.length;i++){
    const a=positions[i-1],b=positions[i], line=document.createElement("i"); line.className="skill-line";
    const x1=a[0],y1=a[1],x2=b[0],y2=b[1], dx=x2-x1,dy=y2-y1;
    line.style.left=`${x1}%`;line.style.top=`${y1}%`;line.style.width=`${Math.hypot(dx,dy)}%`;line.style.transform=`rotate(${Math.atan2(dy,dx)}rad)`;box.prepend(line);
  }
}

function buildProjects(){
  const list=$("#project-list");
  const detail=$("#project-detail");
  if(!list || !detail || !Array.isArray(P.projects)) return;

  list.innerHTML=P.projects.map((p,i)=>`
    <button class="project-file ${i===0?"active":""}" data-id="${p.id}">
      <small>${String(i+1).padStart(2,"0")} // ${p.type}</small>
      <b>${p.name}</b>
    </button>`).join("");

  const show=id=>{
    const p=P.projects.find(x=>x.id===id);
    if(!p) return;
    $$(".project-file").forEach(x=>x.classList.toggle("active",x.dataset.id===id));
    $("#detail-type").textContent=p.type || "MISSION LOG";
    $("#detail-status").textContent=p.status || "STATUS";
    $("#detail-name").textContent=p.name || "PROJECT";
    $("#detail-desc").textContent=p.description || "";
    $("#detail-problem").textContent=p.problem || "—";
    $("#detail-tech").textContent=p.tech || "—";
    $("#detail-role").textContent=p.role || "—";
    $("#detail-learned").textContent=p.learned || "—";
    const l=$("#detail-link");
    if(p.link){
      l.href=p.link;
      l.classList.remove("hidden");
    }else{
      l.removeAttribute("href");
      l.classList.add("hidden");
    }
  };

  $$(".project-file").forEach(b=>b.addEventListener("click",()=>show(b.dataset.id)));

  // Always show the first recovered project instead of an empty placeholder.
  show(P.projects[0]?.id);
}
function buildMission(){
  const box=$("#mission-steps");
  box.innerHTML=P.experience.work.map((x,i)=>`<div class="mission-step">${String(i+1).padStart(2,"0")} — ${x}</div>`).join("");
}

function buildTimeline(){
  $("#timeline-track").innerHTML=P.timeline.map(x=>`<div class="time-node"><b>${x.year}</b><span>${x.label}</span></div>`).join("");
  const all=[...P.learning["Java"],...P.learning["AI / ML"],...P.learning["EECT"],...P.learning["Signals & Digital Systems"],...P.learning["Number Systems"]];
  $("#learning-tags").innerHTML=all.slice(0,22).map(x=>`<span class="tag">${x}</span>`).join("");
}

function buildContact(){
  const c=$("#contact-links"), L=P.links; c.innerHTML="";
  if(L.github)c.innerHTML+=`<a href="${L.github}" target="_blank" rel="noreferrer">GITHUB ↗</a>`;
  if(L.linkedin)c.innerHTML+=`<a href="${L.linkedin}" target="_blank" rel="noreferrer">LINKEDIN ↗</a>`;
  if(L.email)c.innerHTML+=`<a href="mailto:${L.email}">EMAIL ↗</a>`;
  if(L.phoenix_report)c.innerHTML+=`<a href="${L.phoenix_report}" target="_blank" rel="noreferrer">PHOENIX REPORT ↗</a>`;
  if(L.additional_1)c.innerHTML+=`<a href="${L.additional_1}" target="_blank" rel="noreferrer">ADDITIONAL LINK 01 ↗</a>`;
  if(L.additional_2)c.innerHTML+=`<a href="${L.additional_2}" target="_blank" rel="noreferrer">ADDITIONAL LINK 02 ↗</a>`;
  if(!c.innerHTML)c.innerHTML=`<span class="eyebrow">CONTACT LINKS PENDING — REPLACE IN data/portfolio.json</span>`;
}

function buildFinalNetwork(){
  const n=$("#final-network");
  const canvas=document.createElement("canvas"); n.appendChild(canvas);
  const ctx=canvas.getContext("2d");
  function resize(){canvas.width=innerWidth;canvas.height=innerHeight} resize(); addEventListener("resize",resize);
  const pts=Array.from({length:55},()=>({x:Math.random()*innerWidth,y:Math.random()*innerHeight,vx:(Math.random()-.5)*.18,vy:(Math.random()-.5)*.18}));
  function draw(){ctx.clearRect(0,0,canvas.width,canvas.height);for(const p of pts){p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>innerWidth)p.vx*=-1;if(p.y<0||p.y>innerHeight)p.vy*=-1;ctx.fillStyle="rgba(140,233,255,.55)";ctx.fillRect(p.x,p.y,1.5,1.5)}for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++){const a=pts[i],b=pts[j],d=Math.hypot(a.x-b.x,a.y-b.y);if(d<145){ctx.strokeStyle=`rgba(140,233,255,${.11*(1-d/145)})`;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}}requestAnimationFrame(draw)}draw();
}

function observe(){
  const io=new IntersectionObserver(entries=>entries.forEach(e=>{
    if(e.isIntersecting){
      e.target.classList.add("reveal");
      if(e.target.id==="memory-05") $$(".mission-step").forEach((x,i)=>setTimeout(()=>x.classList.add("visible"),i*55));
    }
  }),{threshold:.12});
  $$(".memory-section,.finale").forEach(x=>io.observe(x));
  addEventListener("scroll",()=>$(".topbar").classList.toggle("scrolled",scrollY>30),{passive:true});
}

function buildAll(){
  buildNav();
  buildSkills();
  buildProjects();
  buildMission();
  buildTimeline();
  buildContact();
  buildFinalNetwork();
  observe();
}
boot();
