# WAKE UP: 2035 — Netlify Version

This is the **static Netlify-ready version** of the WAKE UP: 2035 cinematic portfolio.

## Deploy directly to Netlify

### Option A — Drag and drop

1. Extract this ZIP.
2. Open Netlify and sign in.
3. Go to your Sites dashboard.
4. Drag the **entire `WAKE-UP-2035-NETLIFY` folder** into the Netlify deploy area.
5. Netlify will publish the site.

There is no Python installation and no `python app.py` step for this version.

### Option B — GitHub

1. Create a GitHub repository.
2. Upload the contents of this folder.
3. In Netlify choose **Add new site → Import an existing project**.
4. Select the GitHub repository.
5. Build command: leave blank.
6. Publish directory: `.`
7. Deploy.

## Local testing

You can also test the static version locally.

From this folder:

```cmd
py -m http.server 5500
```

Then open:

http://127.0.0.1:5500

## Editing portfolio information

The main content is here:

`assets/js/data.js`

It contains the current resume-backed information and the real links supplied for this portfolio.

## Assets

Put profile photos, project screenshots and certificates in:

`assets/images/`

The current design does not require personal images to run.

## Important

This Netlify version is intentionally static. The original Flask project remains useful for demonstrating Python/backend work.

The Netlify version is the public portfolio deployment; the Flask version can remain your Python assignment/development copy.

## Current real links

GitHub:
https://github.com/donishree

LinkedIn:
https://www.linkedin.com/in/doni-shree-832b80389/

Phoenix AI report:
https://donishree.github.io/flyrank-ml-internship-starter/work/capstone_report.html
